﻿import React, { useState, useEffect } from 'react'
import { authAPI, imageAPI, clusterAPI, adminAPI, checkServerConnection } from './api.js'

// Функция для перевода ошибок
const getErrorMessage = (error) => {
    const message = error.message || 'Unknown error';

    const errorMap = {
        'email_exists': 'Этот email уже зарегистрирован',
        'invalid_credentials': 'Неверный email или пароль',
        'EMAIL_EXISTS': 'Этот email уже зарегистрирован',
        'INVALID_CREDENTIALS': 'Неверный email или пароль',
        'Connection error': 'Ошибка соединения с сервером',
        'Registration failed': 'Ошибка регистрации',
        'Failed to create job': 'Ошибка создания задания',
        'Failed to get jobs': 'Ошибка загрузки заданий',
        'Failed to get users': 'Ошибка загрузки пользователей',
        'upload_failed': 'Ошибка загрузки файла',
        'image_not_found': 'Изображение не найдено',
        'delete_failed': 'Ошибка удаления'
    };

    return errorMap[message] || `Ошибка: ${message}`;
};

function App() {
    const [currentView, setCurrentView] = useState('login')
    const [serverStatus, setServerStatus] = useState('checking')
    const [notification, setNotification] = useState({ show: false, message: '', type: '' })

    useEffect(() => {
        checkServerStatus()
    }, [])

    const showNotification = (message, type = 'info') => {
        setNotification({ show: true, message, type })
        setTimeout(() => setNotification({ show: false, message: '', type: '' }), 5000)
    }

    const checkServerStatus = async () => {
        const result = await checkServerConnection()
        setServerStatus(result.connected ? 'connected' : 'disconnected')
    }

    const handleLogout = () => {
        localStorage.removeItem('access_token')
        setCurrentView('login')
        showNotification('Вы вышли из системы', 'success')
    }

    return (
        <div className="container">
            {/* Уведомление */}
            {notification.show && (
                <div className={`notification ${notification.type}`}>
                    {notification.message}
                    <button onClick={() => setNotification({ show: false, message: '', type: '' })}>×</button>
                </div>
            )}

            <div className="header">
                <h1>📷 Сервис кластеризации изображений</h1>
                <div style={{
                    padding: '5px 10px',
                    borderRadius: '4px',
                    backgroundColor: serverStatus === 'connected' ? '#d4edda' : '#f8d7da',
                    color: serverStatus === 'connected' ? '#155724' : '#721c24',
                    fontSize: '14px',
                    marginBottom: '10px'
                }}>
                    Статус сервера: {serverStatus === 'connected' ? '✅ Подключен' : '❌ Отключен'}
                </div>

                {currentView !== 'login' && currentView !== 'register' && (
                    <div className="nav">
                        <button onClick={() => setCurrentView('images')}>Мои изображения</button>
                        <button onClick={() => setCurrentView('clustering')}>Кластеризация</button>
                        <button onClick={() => setCurrentView('admin')}>Админ-панель</button>
                        <button className="logout" onClick={handleLogout}>Выйти</button>
                    </div>
                )}
            </div>

            {currentView === 'login' && (
                <LoginView
                    onLogin={() => setCurrentView('images')}
                    onSwitch={() => setCurrentView('register')}
                    serverStatus={serverStatus}
                    showNotification={showNotification}
                />
            )}
            {currentView === 'register' && (
                <RegisterView
                    onSwitch={() => setCurrentView('login')}
                    serverStatus={serverStatus}
                    showNotification={showNotification}
                />
            )}
            {currentView === 'images' && <ImageView showNotification={showNotification} />}
            {currentView === 'clustering' && <ClusteringView showNotification={showNotification} />}
            {currentView === 'admin' && <AdminView showNotification={showNotification} />}
        </div>
    )
}

function LoginView({ onLogin, onSwitch, serverStatus, showNotification }) {
    const [formData, setFormData] = useState({ email: '', password: '' })
    const [loading, setLoading] = useState(false)

    const handleSubmit = async (e) => {
        e.preventDefault()

        if (serverStatus !== 'connected') {
            showNotification('Сервер не доступен. Запустите бэкенд сначала.', 'error')
            return
        }

        setLoading(true)
        try {
            const response = await authAPI.login(formData.email, formData.password)
            localStorage.setItem('access_token', response.data.access_token)
            showNotification('Вход выполнен успешно!', 'success')
            onLogin()
        } catch (error) {
            showNotification(getErrorMessage(error), 'error')
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="form-container">
            <h2>Вход в систему</h2>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Email:</label>
                    <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                        placeholder="user@example.com"
                    />
                </div>
                <div className="form-group">
                    <label>Пароль:</label>
                    <input
                        type="password"
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        required
                        placeholder="Введите пароль"
                    />
                </div>
                <button type="submit" className="btn" disabled={loading}>
                    {loading ? 'Вход...' : 'Войти'}
                </button>
            </form>
            <button onClick={onSwitch} style={{ marginTop: '10px', background: 'none', border: 'none', color: '#007bff', cursor: 'pointer' }}>
                Нет аккаунта? Зарегистрируйтесь
            </button>
        </div>
    )
}

function RegisterView({ onSwitch, serverStatus, showNotification }) {
    const [formData, setFormData] = useState({ username: '', email: '', password: '' })
    const [loading, setLoading] = useState(false)

    const handleSubmit = async (e) => {
        e.preventDefault()

        if (serverStatus !== 'connected') {
            showNotification('Сервер не доступен. Запустите бэкенд сначала.', 'error')
            return
        }

        setLoading(true)
        try {
            await authAPI.register(formData)
            showNotification('Регистрация успешна! Теперь войдите в систему.', 'success')
            onSwitch()
        } catch (error) {
            showNotification(getErrorMessage(error), 'error')
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="form-container">
            <h2>Регистрация</h2>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Имя пользователя:</label>
                    <input
                        type="text"
                        value={formData.username}
                        onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                        required
                        placeholder="Введите имя"
                    />
                </div>
                <div className="form-group">
                    <label>Email:</label>
                    <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                        placeholder="user@example.com"
                    />
                </div>
                <div className="form-group">
                    <label>Пароль:</label>
                    <input
                        type="password"
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        required
                        placeholder="Введите пароль"
                    />
                </div>
                <button type="submit" className="btn" disabled={loading}>
                    {loading ? 'Регистрация...' : 'Зарегистрироваться'}
                </button>
            </form>
            <button onClick={onSwitch} style={{ marginTop: '10px', background: 'none', border: 'none', color: '#007bff', cursor: 'pointer' }}>
                Уже есть аккаунт? Войдите
            </button>
        </div>
    )
}

function ImageView({ showNotification }) {
    const [images, setImages] = useState([])
    const [loading, setLoading] = useState(false)

    useEffect(() => {
        loadImages()
    }, [])

    const loadImages = async () => {
        try {
            const response = await imageAPI.getAll()
            setImages(response.data)
        } catch (error) {
            console.error('Error loading images:', error)
        }
    }

    const handleFileUpload = async (e) => {
        const file = e.target.files[0]
        if (file) {
            setLoading(true)
            try {
                await imageAPI.upload(file)
                showNotification(`Файл "${file.name}" успешно загружен!`, 'success')
                loadImages() // Reload images list
            } catch (error) {
                showNotification(getErrorMessage(error), 'error')
            } finally {
                setLoading(false)
            }
        }
    }

    const handleDeleteImage = async (imageId) => {
        if (confirm('Удалить изображение?')) {
            try {
                await imageAPI.delete(imageId)
                showNotification('Изображение удалено', 'success')
                loadImages() // Reload images list
            } catch (error) {
                showNotification(getErrorMessage(error), 'error')
            }
        }
    }

    return (
        <div>
            <h2>Мои изображения</h2>
            <div className="form-container">
                <div className="form-group">
                    <label>Загрузить изображение:</label>
                    <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        disabled={loading}
                    />
                    {loading && <p>Загрузка...</p>}
                </div>
            </div>

            <div className="image-grid">
                {images.map(image => (
                    <div key={image.id} className="image-card">
                        <h4>📸 {image.filename}</h4>
                        <p>Размер: {(image.file_size / 1024).toFixed(1)} KB</p>
                        <p>Загружено: {new Date(image.uploaded_at).toLocaleDateString()}</p>
                        <button
                            onClick={() => handleDeleteImage(image.id)}
                            style={{ background: '#dc3545', color: 'white', border: 'none', padding: '5px 10px', borderRadius: '4px', cursor: 'pointer' }}
                        >
                            Удалить
                        </button>
                    </div>
                ))}
                {images.length === 0 && (
                    <p>Нет загруженных изображений</p>
                )}
            </div>
        </div>
    )
}

function ClusteringView({ showNotification }) {
    const [jobs, setJobs] = useState([])
    const [formData, setFormData] = useState({
        name: '',
        algorithm: 'kmeans',
        parameters: { n_clusters: 3 }
    })

    const handleSubmit = async (e) => {
        e.preventDefault()
        try {
            await clusterAPI.createJob(formData)
            showNotification('Задание на кластеризацию создано!', 'success')
            setFormData({ name: '', algorithm: 'kmeans', parameters: { n_clusters: 3 } })
            // Reload jobs
            const response = await clusterAPI.getJobs()
            setJobs(response.data)
        } catch (error) {
            showNotification(getErrorMessage(error), 'error')
        }
    }

    useEffect(() => {
        loadJobs()
    }, [])

    const loadJobs = async () => {
        try {
            const response = await clusterAPI.getJobs()
            setJobs(response.data)
        } catch (error) {
            console.error('Error loading jobs:', error)
        }
    }

    return (
        <div>
            <h2>Кластеризация изображений</h2>

            <div className="form-container">
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label>Название задания:</label>
                        <input
                            type="text"
                            value={formData.name}
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                            placeholder="Например: Анализ фотографий природы"
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label>Алгоритм:</label>
                        <select
                            value={formData.algorithm}
                            onChange={(e) => setFormData({ ...formData, algorithm: e.target.value })}
                        >
                            <option value="kmeans">K-Means</option>
                            <option value="dbscan">DBSCAN</option>
                        </select>
                    </div>

                    {formData.algorithm === 'kmeans' && (
                        <div className="form-group">
                            <label>Количество кластеров:</label>
                            <input
                                type="number"
                                value={formData.parameters.n_clusters}
                                onChange={(e) => setFormData({
                                    ...formData,
                                    parameters: { n_clusters: parseInt(e.target.value) }
                                })}
                                min="2"
                                max="10"
                            />
                        </div>
                    )}

                    <button type="submit" className="btn">Запустить кластеризацию</button>
                </form>
            </div>

            <div className="form-container">
                <h3>📊 История заданий</h3>
                <div className="image-grid">
                    {jobs.map(job => (
                        <div key={job.id} className="image-card">
                            <h4>{job.name}</h4>
                            <p>Алгоритм: {job.algorithm}</p>
                            <p>Статус: <span style={{ color: 'green' }}>Завершено</span></p>
                            <p>Создано: {new Date(job.created_at).toLocaleString()}</p>
                        </div>
                    ))}
                    {jobs.length === 0 && (
                        <p>Нет созданных заданий</p>
                    )}
                </div>
            </div>
        </div>
    )
}

function AdminView({ showNotification }) {
    const [users, setUsers] = useState([])

    useEffect(() => {
        loadUsers()
    }, [])

    const loadUsers = async () => {
        try {
            const response = await adminAPI.getUsers()
            setUsers(response.data)
        } catch (error) {
            console.error('Error loading users:', error)
        }
    }

    return (
        <div>
            <h2>⚙️ Админ-панель</h2>

            <div className="form-container">
                <h3>👥 Пользователи</h3>
                <div className="image-grid">
                    {users.map(user => (
                        <div key={user.id} className="image-card">
                            <p><strong>Имя:</strong> {user.username}</p>
                            <p><strong>Email:</strong> {user.email}</p>
                        </div>
                    ))}
                    {users.length === 0 && (
                        <p>Нет зарегистрированных пользователей</p>
                    )}
                </div>
            </div>
        </div>
    )
}

export default App