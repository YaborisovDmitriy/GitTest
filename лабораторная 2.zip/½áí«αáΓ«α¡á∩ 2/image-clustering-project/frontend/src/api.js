import axios from 'axios'

const API_BASE_URL = 'http://localhost:8000'

const api = axios.create({
    baseURL: API_BASE_URL,
    timeout: 10000,
})

// Check server connection
export const checkServerConnection = async () => {
    try {
        const response = await api.get('/')
        return { connected: true, data: response.data }
    } catch (error) {
        return { connected: false, error: error.message }
    }
}

export const authAPI = {
    login: async (email, password) => {
        try {
            const response = await api.post('/login', { email, password })
            if (!response.data.success) {
                throw new Error(response.data.error)
            }
            return { data: response.data }
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Connection error')
        }
    },

    register: async (userData) => {
        try {
            const response = await api.post('/register', userData)
            if (!response.data.success) {
                throw new Error(response.data.error)
            }
            return { data: response.data }
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Registration failed')
        }
    },
}

export const clusterAPI = {
    createJob: async (jobData) => {
        try {
            const response = await api.post('/cluster-jobs', jobData)
            return { data: response.data }
        } catch (error) {
            throw new Error('Failed to create job')
        }
    },

    getJobs: async () => {
        try {
            const response = await api.get('/cluster-jobs')
            return { data: response.data.jobs }
        } catch (error) {
            throw new Error('Failed to get jobs')
        }
    },
}

export const adminAPI = {
    getUsers: async () => {
        try {
            const response = await api.get('/users')
            return { data: response.data.users }
        } catch (error) {
            throw new Error('Failed to get users')
        }
    },
}
export const imageAPI = {
    upload: async (file) => {
        const formData = new FormData()
        formData.append('file', file)
        const response = await api.post('/images/', formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
        })
        if (!response.data.success) {
            throw new Error(response.data.error)
        }
        return { data: response.data }
    },

    getAll: async () => {
        const response = await api.get('/images/')
        if (!response.data.success) {
            throw new Error('Failed to get images')
        }
        return { data: response.data.images }
    },

    delete: async (id) => {
        const response = await api.delete(`/images/${id}`)
        if (!response.data.success) {
            throw new Error(response.data.error)
        }
        return { data: response.data }
    },
}

export default api