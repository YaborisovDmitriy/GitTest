from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
import os
import uuid
from datetime import datetime

app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Simple storage
users_db = []
jobs_db = []
images_db = []

# Create uploads directory
os.makedirs("uploads", exist_ok=True)


class UserCreate(BaseModel):
    username: str
    email: str
    password: str


class UserLogin(BaseModel):
    email: str
    password: str


class ClusterJobCreate(BaseModel):
    name: str
    algorithm: str
    parameters: dict


@app.get("/")
def root():
    return {"status": "ok", "message": "Server is running"}


@app.post("/register")
def register(user: UserCreate):
    print(f"🔔 Registration attempt: {user.email}")

    # Check if user exists
    for u in users_db:
        if u["email"] == user.email:
            return {"success": False, "error": "email_exists"}

    # Create user
    new_user = {
        "id": len(users_db) + 1,
        "username": user.username,
        "email": user.email,
        "password": user.password
    }
    users_db.append(new_user)
    print(f"✅ User registered: {user.email}")

    return {
        "success": True,
        "user_id": new_user["id"],
        "username": new_user["username"],
        "email": new_user["email"]
    }


@app.post("/login")
def login(user: UserLogin):
    print(f"🔔 Login attempt: {user.email}")

    for u in users_db:
        if u["email"] == user.email and u["password"] == user.password:
            return {
                "success": True,
                "access_token": f"token_{u['id']}",
                "token_type": "bearer"
            }

    return {"success": False, "error": "invalid_credentials"}


# НОВЫЕ ЭНДПОИНТЫ ДЛЯ ИЗОБРАЖЕНИЙ
@app.post("/images/")
async def upload_image(file: UploadFile = File(...)):
    print(f"📸 Upload attempt: {file.filename}")

    try:
        # Generate unique filename
        file_extension = file.filename.split('.')[-1]
        unique_filename = f"{uuid.uuid4()}.{file_extension}"
        file_location = f"uploads/{unique_filename}"

        # Save file
        with open(file_location, "wb") as buffer:
            content = await file.read()
            buffer.write(content)

        # Store image info
        image_info = {
            "id": len(images_db) + 1,
            "filename": file.filename,
            "unique_filename": unique_filename,
            "file_size": len(content),
            "uploaded_at": datetime.now().isoformat(),
            "file_path": file_location
        }
        images_db.append(image_info)

        print(f"✅ Image uploaded: {file.filename}")

        return {
            "success": True,
            "id": image_info["id"],
            "filename": image_info["filename"],
            "file_size": image_info["file_size"],
            "uploaded_at": image_info["uploaded_at"]
        }

    except Exception as e:
        print(f"❌ Upload error: {e}")
        return {"success": False, "error": "upload_failed"}


@app.get("/images/")
def get_images():
    return {
        "success": True,
        "images": [
            {
                "id": img["id"],
                "filename": img["filename"],
                "file_size": img["file_size"],
                "uploaded_at": img["uploaded_at"]
            }
            for img in images_db
        ]
    }


@app.delete("/images/{image_id}")
def delete_image(image_id: int):
    try:
        # Find image
        image_to_delete = None
        for img in images_db:
            if img["id"] == image_id:
                image_to_delete = img
                break

        if not image_to_delete:
            return {"success": False, "error": "image_not_found"}

        # Delete file from disk
        if os.path.exists(image_to_delete["file_path"]):
            os.remove(image_to_delete["file_path"])

        # Remove from database
        images_db.remove(image_to_delete)

        print(f"✅ Image deleted: {image_to_delete['filename']}")
        return {"success": True, "message": "image_deleted"}

    except Exception as e:
        print(f"❌ Delete error: {e}")
        return {"success": False, "error": "delete_failed"}


@app.post("/cluster-jobs")
def create_cluster_job(job: ClusterJobCreate):
    new_job = {
        "id": len(jobs_db) + 1,
        "name": job.name,
        "algorithm": job.algorithm,
        "parameters": job.parameters,
        "status": "completed",
        "created_at": datetime.now().isoformat()
    }
    jobs_db.append(new_job)

    return {"success": True, "job_id": new_job["id"]}


@app.get("/cluster-jobs")
def get_cluster_jobs():
    return {"success": True, "jobs": jobs_db}


@app.get("/users")
def get_users():
    return {"success": True, "users": users_db}


if __name__ == "__main__":
    print("🚀 Server with image upload starting on http://localhost:8000")
    print("📖 Docs: http://localhost:8000/docs")
    uvicorn.run(app, host="0.0.0.0", port=8000)